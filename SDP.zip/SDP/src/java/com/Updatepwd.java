/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 *
 * @author admin
 */
public class Updatepwd extends HttpServlet {
static Connection con=null;
    static PreparedStatement p=null;
    static ResultSet rs=null;
    /**
     * Processes requests for both HTTP <code>GET</code> and <code>POST</code>
     * methods.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sdp?zeroDateTimeBehavior=convertToNull","root","root");
            
            String email=(String)request.getParameter("idnm");
            String fbnm=(String)request.getParameter("fbnm");
            String curpwd=(String)request.getParameter("curpwd");
            String newpwd=(String)request.getParameter("newpwd");
            String forgot=(String)request.getParameter("forgot");
            
            if(forgot.equals("t"))
            {
                String q1="SELECT * FROM sdp.login where email_id=? and favbooknm=?";
                p=con.prepareStatement(q1);
                p.setString(1,email);
                p.setString(2,fbnm.toLowerCase());
                rs=p.executeQuery();
               
                if(rs.next())
                {
                    String q2="Update sdp.login set pwd=? where email_id=?";
                    p=con.prepareStatement(q2);
                    p.setString(1,newpwd);
                    p.setString(2,email);
                    
                    int i=p.executeUpdate();
                    RequestDispatcher r=request.getRequestDispatcher("login.jsp");
                    r.forward(request,response);
                }
                else{
                    request.setAttribute("error","3");
                    RequestDispatcher r=request.getRequestDispatcher("login.jsp");
                    r.forward(request,response);
                }   
            }
            else if(forgot.equals("f"))
            {
                String q1="SELECT * FROM sdp.login where email_id=? and pwd=?";
                p=con.prepareStatement(q1);
                p.setString(1,email);
                p.setString(2,curpwd);
                rs=p.executeQuery();
                if(rs.next())
                {
                    String q2="Update sdp.login set pwd=? where email_id=?";
                    p=con.prepareStatement(q2);
                    p.setString(1,newpwd);
                    p.setString(2,email);
                    
                    int i=p.executeUpdate();
                    RequestDispatcher r=request.getRequestDispatcher("login.jsp");
                    r.forward(request,response);
                }
                else{
                    request.setAttribute("error","2");
                    RequestDispatcher r=request.getRequestDispatcher("login.jsp");
                    r.forward(request,response);
                }    
            }
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
    }

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
