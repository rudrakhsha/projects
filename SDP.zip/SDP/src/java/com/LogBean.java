/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com;
import java.beans.*;
import java.sql.*;
/**
 *
 * @author admin
 */
public class LogBean {
    String id,passwd,u;
    boolean status=false,logfail=false;

    public boolean isLogfail() {
        return logfail;
    }

    public void setLogfail(boolean logfail) {
        this.logfail = logfail;
    }
    static Connection con=null;
    static PreparedStatement p=null;
    static ResultSet rs=null;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public String getPasswd() {
        return passwd;
    }

    public void setPasswd(String passwd) {
        this.passwd = passwd;
    }

    public String getU() {
        return u;
    }

    public void setU(String u) {
        this.u = u;
    }

    public boolean isStatus() {
        return status;
    }

    public void setStatus(boolean status) {
        this.status = status;
    }
   
    public boolean validate(String i,String pw)
    {
        status=false;logfail=false;
        try{
            Class.forName("com.mysql.jdbc.Driver");
            con=DriverManager.getConnection("jdbc:mysql://localhost:3306/sdp?zeroDateTimeBehavior=convertToNull","root","root");
            String q="SELECT * FROM sdp.login where email_id=? and pwd=?";
            p=con.prepareStatement(q);
            p.setString(1,i);
            p.setString(2,pw);
            rs=p.executeQuery();
            if(rs.next()==true){
                if(i.equals(rs.getString("email_id"))&&pw.equals(rs.getString("pwd")))
                {
                    u=rs.getString("uname");
                    id=i;
                    System.out.println("Bean");
                    status=true;
                    logfail=false;
                }
            }
            
        }
        catch(Exception e)
        {
            System.out.println(e);
        }
        if(!status)
        {
            System.out.println("L");
            logfail=true;
            
        }
        return status;
    }
}
