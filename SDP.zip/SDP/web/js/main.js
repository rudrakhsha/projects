$(document).ready(function(){
	$nav = $('.nav1');
	$toggleCollapse = $('.toggle-collapse');

	$toggleCollapse.click(function(){
		$nav.toggleClass('collapse');
	})
});
